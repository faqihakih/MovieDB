package com.akih.moviedb.ui.movie

import androidx.lifecycle.LiveData
import androidx.lifecycle.ViewModel
import com.akih.moviedb.data.source.remote.response.Movie
import com.akih.moviedb.data.MovieRepository

class MovieViewModel (private val movieRepository: MovieRepository) : ViewModel() {
    fun getAllMovie(): LiveData<List<Movie>> = movieRepository.getAllMovie()
}