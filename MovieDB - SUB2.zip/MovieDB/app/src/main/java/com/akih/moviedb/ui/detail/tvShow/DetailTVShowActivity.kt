package com.akih.moviedb.ui.detail.tvShow

import android.annotation.SuppressLint
import android.content.Intent
import android.net.Uri
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import com.akih.moviedb.data.source.remote.response.TVShow
import com.akih.moviedb.databinding.ActivityDetailTVShowBinding
import com.akih.moviedb.ui.detail.movie.DetailMovieActivity
import com.akih.moviedb.viewModel.ViewModelFactory
import com.bumptech.glide.Glide

class DetailTVShowActivity : AppCompatActivity() {
    private lateinit var binding: ActivityDetailTVShowBinding
    private lateinit var viewModel: DetailTVShowViewModel
    private lateinit var factory: ViewModelFactory

    companion object{
        const val EXTRA_ID = "extra_id"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityDetailTVShowBinding.inflate(layoutInflater)
        setContentView(binding.root)
        initViewModel()
        getId()
        observe()
    }

    private fun initViewModel(){
        factory = ViewModelFactory.getInstance(this)
        viewModel = ViewModelProvider(this, factory)[DetailTVShowViewModel::class.java]
    }

    private fun observe(){
        viewModel.getTVShow().observe(this, Observer { initView(it) })
        viewModel.getTVShow().observe(this, Observer { watchTrailer(it) })
    }

    private fun getId(){
        val id = intent.extras
        if (id != null){
            val data = id.getInt(DetailMovieActivity.EXTRA_ID, 0)
            viewModel.setSelectedTVShow(data)
        }
    }

    @SuppressLint("SetTextI18n")
    private fun initView(itemData : TVShow){
        Glide.with(this.applicationContext).load(itemData.banner).into(binding.ivBanner)
        binding.apply {
            tvTitle.text = "${itemData.title} - (${itemData.year})"
            tvDuration.text = itemData.duration
            tvRating.text = itemData.rating
            tvGenre.text = itemData.genre
            tvSynopsis.text = itemData.synopsis
        }
    }

    private fun watchTrailer(itemData: TVShow){
        binding.btnTrailer.setOnClickListener {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(itemData.trailer)))
        }
    }
}