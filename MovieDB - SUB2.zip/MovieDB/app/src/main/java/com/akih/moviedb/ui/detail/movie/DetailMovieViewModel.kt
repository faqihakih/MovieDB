package com.akih.moviedb.ui.detail.movie

import androidx.lifecycle.LiveData
import androidx.lifecycle.ViewModel
import com.akih.moviedb.data.source.remote.response.Movie
import com.akih.moviedb.data.MovieRepository

class DetailMovieViewModel (private val movieRepository: MovieRepository) : ViewModel() {
    private var movieId : Int = 0
    fun setSelectedMovie(moviesId: Int) {
        this.movieId = moviesId
    }

    fun getMovie(): LiveData<Movie> = movieRepository.getMovieDetail(movieId)
}