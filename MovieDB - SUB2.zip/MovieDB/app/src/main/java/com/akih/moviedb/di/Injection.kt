package com.akih.moviedb.di

import android.content.Context
import com.akih.moviedb.data.MovieRepository
import com.akih.moviedb.data.source.remote.RemoteDataSource
import com.akih.moviedb.utils.JSONHelper

object Injection {
    fun provideRepository(context: Context): MovieRepository {

        val remoteDataSource = RemoteDataSource.getInstance(JSONHelper(context))

        return MovieRepository.getInstance(remoteDataSource)
    }
}