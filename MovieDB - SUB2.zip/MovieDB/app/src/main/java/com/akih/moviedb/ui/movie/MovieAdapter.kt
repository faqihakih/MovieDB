package com.akih.moviedb.ui.movie

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.akih.moviedb.data.source.remote.response.Movie
import com.akih.moviedb.databinding.ItemCardBinding
import com.bumptech.glide.Glide

class MovieAdapter(private val movieAdapterInterface: MovieAdapterInterface) : RecyclerView.Adapter<MovieAdapter.MovieViewHolder>(){
    private val movies = ArrayList<Movie>()
    fun setList(mMovie: List<Movie>){
        this.movies.clear()
        this.movies.addAll(mMovie)
        notifyDataSetChanged()
    }

    inner class MovieViewHolder(private val binding : ItemCardBinding) : RecyclerView.ViewHolder(binding.root) {
        fun bind(movie: Movie){
            binding.root.setOnClickListener { movieAdapterInterface.onTap(movie) }
            binding.root.setOnLongClickListener {
                movieAdapterInterface.onLongTap(movie)
                return@setOnLongClickListener true
            }
            Glide.with(binding.root).load(movie.banner).into(binding.ivBanner)
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MovieViewHolder {
        val view = ItemCardBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return MovieViewHolder(view)
    }

    override fun getItemCount(): Int = movies.size

    override fun onBindViewHolder(holder: MovieViewHolder, position: Int) = holder.bind(movies[position])
}