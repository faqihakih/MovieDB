package com.akih.moviedb.data.source.remote

import com.akih.moviedb.data.source.remote.response.Movie
import com.akih.moviedb.data.source.remote.response.TVShow
import com.akih.moviedb.utils.JSONHelper

class RemoteDataSource private constructor(private val jsonHelper: JSONHelper) {

    companion object {
        @Volatile
        private var instance: RemoteDataSource? = null

        fun getInstance(helper: JSONHelper): RemoteDataSource =
            instance ?: synchronized(this) {
                RemoteDataSource(helper).apply { instance = this }
            }
    }

    fun getAllMovies(callback: LoadMoviesCallback) {
        callback.onAllMoviesReceived(jsonHelper.loadMovie())
    }
    fun getAllTVShow(callback: LoadTVShowCallback) {
        callback.onAllTVShowReceived(jsonHelper.loadTVShow())
    }
    fun getMoviesDetail(movieId : Int, callback: LoadMoviesDetailCallback) {
        callback.onAllMoviesDetailReceived(jsonHelper.loadMovieDetail(movieId))
    }
    fun getTVShowDetail(tvShowId : Int, callback: LoadTVShowDetailCallback) {
        callback.onAllTVShowDetailReceived(jsonHelper.loadTVShowDetail(tvShowId))
    }


    interface LoadMoviesCallback {
        fun onAllMoviesReceived(moviesResponses: List<Movie>)
    }

    interface LoadTVShowCallback {
        fun onAllTVShowReceived(tvShowResponses: List<TVShow>)
    }

    interface LoadMoviesDetailCallback {
        fun onAllMoviesDetailReceived(movieDetailResponses: Movie)
    }

    interface LoadTVShowDetailCallback {
        fun onAllTVShowDetailReceived(tvShowDetailResponses: TVShow)
    }

}