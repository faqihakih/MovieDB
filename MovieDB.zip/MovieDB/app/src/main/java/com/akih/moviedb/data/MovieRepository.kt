package com.akih.moviedb.data

import android.util.Log
import androidx.lifecycle.LiveData
import androidx.paging.LivePagedListBuilder
import androidx.paging.PagedList
import com.akih.moviedb.data.source.local.LocalMovieDataSource
import com.akih.moviedb.data.source.local.entity.MovieEntity
import com.akih.moviedb.data.source.local.entity.TVShowEntity
import com.akih.moviedb.data.source.local.room.Movie
import com.akih.moviedb.data.source.local.room.TVShow
import com.akih.moviedb.data.source.remote.RemoteDataSource
import com.akih.moviedb.data.source.remote.response.MovieResponse
import com.akih.moviedb.utils.ApiResponse
import com.akih.moviedb.utils.AppExecutor
import com.akih.moviedb.utils.NetworkBoundResource
import com.akih.moviedb.utils.Resource

class MovieRepository private constructor(
    private val remoteDataSource: RemoteDataSource,
    private val localDataSource: LocalMovieDataSource,
    private val appExecutor: AppExecutor,
    ) : MovieDataSource {

    companion object {
        @Volatile
        private var instance: MovieRepository? = null
        fun getInstance(remoteData: RemoteDataSource, localData: LocalMovieDataSource, appExecutor: AppExecutor): MovieRepository =
            instance ?: synchronized(this) {
                MovieRepository(remoteData, localData, appExecutor).apply { instance = this }
            }
    }

    override fun getAllMovie(): LiveData<Resource<PagedList<Movie>>> {
        return object : NetworkBoundResource<PagedList<Movie>, List<MovieEntity>>(appExecutor) {
            public override fun loadFromDB(): LiveData<PagedList<Movie>> {
                val config = PagedList.Config.Builder()
                        .setEnablePlaceholders(false)
                        .setInitialLoadSizeHint(4)
                        .setPageSize(4)
                        .build()
                return LivePagedListBuilder(localDataSource.readAllMovies(), config).build()
            }

            override fun shouldFetch(data: PagedList<Movie>?): Boolean =
                    data == null || data.isEmpty()

            public override fun createCall(): LiveData<ApiResponse<List<MovieEntity>>> =
                    remoteDataSource.getMovie()

            public override fun saveCallResult(data: List<MovieEntity>) {
                val courseList = ArrayList<Movie>()
                for (response in data) {
                    val course = Movie(
                            response.id,
                            response.title,
                            response.year,
                            response.duration,
                            response.rating,
                            response.genre,
                            response.synopsis,
                            response.banner,
                            response.trailer)
                    courseList.add(course)
                }

                localDataSource.insertMovies(courseList)
            }
        }.asLiveData()
    }

    override fun getAllTVShow(): LiveData<Resource<PagedList<TVShow>>> {
        return object : NetworkBoundResource<PagedList<TVShow>, List<TVShowEntity>>(appExecutor) {
            public override fun loadFromDB(): LiveData<PagedList<TVShow>> {
                val config = PagedList.Config.Builder()
                        .setEnablePlaceholders(false)
                        .setInitialLoadSizeHint(4)
                        .setPageSize(4)
                        .build()
                return LivePagedListBuilder(localDataSource.readAllShows(), config).build()
            }

            override fun shouldFetch(data: PagedList<TVShow>?): Boolean =
                    data == null || data.isEmpty()

            public override fun createCall(): LiveData<ApiResponse<List<TVShowEntity>>> =
                    remoteDataSource.getShow()

            public override fun saveCallResult(data: List<TVShowEntity>) {
                val courseList = ArrayList<TVShow>()
                for (response in data) {
                    val course = TVShow(
                            response.id,
                            response.title,
                            response.year,
                            response.duration,
                            response.rating,
                            response.genre,
                            response.synopsis,
                            response.banner,
                            response.trailer)
                    courseList.add(course)
                }

                localDataSource.insertShows(courseList)
            }
        }.asLiveData()
    }

    override fun getMovieDetail(MovieId: Int): LiveData<Resource<Movie>> {
        return object : NetworkBoundResource<Movie, Movie>(appExecutor){
            override fun saveCallResult(body: Movie) {
                localDataSource.updateMovies(body, MovieId)
            }

            override fun createCall(): LiveData<ApiResponse<Movie>> {
//                return remoteDataSource.getMovieDetail(MovieId)
                TODO("Not yet implemented")
            }

            override fun shouldFetch(data: Movie?): Boolean{
                return data == null
            }

            override fun loadFromDB(): LiveData<Movie> {
                return localDataSource.getDetailMovie(MovieId)
            }

        }.asLiveData()
    }

    override fun getTVShowDetail(TVShowId: Int): LiveData<Resource<TVShow>> {
        return object : NetworkBoundResource<TVShow, TVShow>(appExecutor){

            override fun saveCallResult(data: TVShow) {
                localDataSource.updateShows(data, TVShowId)
            }

            override fun createCall(): LiveData<ApiResponse<TVShow>> {
//                return remoteDataSource.getShowDetail(TVShowId)
                TODO("Not yet implemented")
            }

            override fun shouldFetch(data: TVShow?): Boolean{
                return data == null
            }

            override fun loadFromDB(): LiveData<TVShow> {
                return localDataSource.getDetailShow(TVShowId)
            }

        }.asLiveData()
    }

    override fun setFavMovie(movieId: Movie, value: Boolean) {
        appExecutor.diskIO().execute{localDataSource.setFavMovie(movieId, value)}
    }

    override fun setFavTVShow(TVShowId: TVShow, value: Boolean) {
        appExecutor.diskIO().execute{localDataSource.setFavShow(TVShowId, value)}
    }

    override fun getFavMovie(): LiveData<PagedList<Movie>> {
        val favorite = PagedList.Config.Builder()
            .setEnablePlaceholders(false)
            .setInitialLoadSizeHint(4)
            .setPageSize(4)
            .build()
        return LivePagedListBuilder(localDataSource.getFavMovies(), favorite).build()
    }

    override fun getFavTVShow(): LiveData<PagedList<TVShow>> {
        val favorite = PagedList.Config.Builder()
            .setEnablePlaceholders(false)
            .setInitialLoadSizeHint(4)
            .setPageSize(4)
            .build()
        return LivePagedListBuilder(localDataSource.getFavShows(), favorite).build()
    }

}