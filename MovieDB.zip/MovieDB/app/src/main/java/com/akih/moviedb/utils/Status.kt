package com.akih.moviedb.utils

enum class Status {
    SUCCESS,
    ERROR,
    LOADING
}