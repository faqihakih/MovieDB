package com.akih.moviedb.data.source.remote.response

enum class StatusResponse {
    SUCCESS,
    EMPTY,
    ERROR
}