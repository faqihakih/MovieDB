package com.akih.moviedb.utils

enum class StatusResponse {
    SUCCESS,
    EMPTY,
    ERROR
}