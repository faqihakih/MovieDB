package com.akih.moviedb.ui.favorite.tvShowFavorite

import com.akih.moviedb.data.source.local.room.TVShow

interface TVShowAdapterInterface {
    fun onTap(tvShow : TVShow)
    fun onLongTap(tvShow : TVShow)
}