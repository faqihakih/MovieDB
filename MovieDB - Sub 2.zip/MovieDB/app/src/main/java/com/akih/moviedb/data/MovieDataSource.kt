package com.akih.moviedb.data

import androidx.lifecycle.LiveData
import com.akih.moviedb.data.source.remote.response.Movie
import com.akih.moviedb.data.source.remote.response.TVShow

interface MovieDataSource {
    fun getAllMovie() : LiveData<List<Movie>>
    fun getAllTVShow() : LiveData<List<TVShow>>
    fun getMovieDetail(MovieId : Int) : LiveData<Movie>
    fun getTVShowDetail(TVShowId : Int) : LiveData<TVShow>
}