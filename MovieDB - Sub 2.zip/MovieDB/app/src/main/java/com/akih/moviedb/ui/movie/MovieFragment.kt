package com.akih.moviedb.ui.movie

import android.content.Intent
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.GridLayoutManager
import com.akih.moviedb.data.source.remote.response.Movie
import com.akih.moviedb.databinding.FragmentMovieBinding
import com.akih.moviedb.ui.detail.movie.DetailMovieActivity
import com.akih.moviedb.viewModel.ViewModelFactory

class MovieFragment : Fragment(), MovieAdapterInterface {
    private var _binding : FragmentMovieBinding? = null
    private val binding get() = _binding!!
    private lateinit var viewModel: MovieViewModel
    private lateinit var factory : ViewModelFactory

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        _binding = FragmentMovieBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        initView()
        initViewModel()
        observe()
    }

    private fun initView(){
        initRecyclerView()
    }

    private fun initRecyclerView(){
        binding.rvMovie.apply {
            layoutManager = GridLayoutManager(requireContext(), 2)
            setHasFixedSize(true)
            adapter = MovieAdapter(this@MovieFragment)
        }
    }

    private fun handleListMovie(movies : List<Movie>){
        binding.rvMovie.adapter?.let { adapter ->
            if (adapter is MovieAdapter){
                adapter.setList(movies)
            }
        }
    }

    private fun initViewModel(){
        factory = ViewModelFactory.getInstance(requireActivity())
        viewModel = ViewModelProvider(this, factory)[MovieViewModel::class.java]
    }

    private fun observe(){
        viewModel.getAllMovie().observe(viewLifecycleOwner, Observer { handleListMovie(it) })
    }

    override fun onTap(movie: Movie) {
        startActivity(Intent(activity, DetailMovieActivity::class.java).also {
            it.putExtra(DetailMovieActivity.EXTRA_ID, movie.id)
        })
    }

    override fun onLongTap(movie: Movie) {
        Toast.makeText(context, "You Click On ${movie.title} Movie", Toast.LENGTH_LONG).show()
    }
}