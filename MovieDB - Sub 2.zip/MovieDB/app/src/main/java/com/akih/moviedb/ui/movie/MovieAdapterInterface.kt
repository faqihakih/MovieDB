package com.akih.moviedb.ui.movie

import com.akih.moviedb.data.source.remote.response.Movie

interface MovieAdapterInterface {
    fun onTap(movie : Movie)
    fun onLongTap(movie : Movie)
}