package com.akih.moviedb.ui.tvShow

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.akih.moviedb.data.source.remote.response.TVShow
import com.akih.moviedb.databinding.ItemCardBinding
import com.bumptech.glide.Glide

class TVShowAdapter(
        private val tvShows : ArrayList<TVShow>,
        private val tvShowAdapterInterface: TVShowAdapterInterface
) : RecyclerView.Adapter<TVShowAdapter.TVShowViewHolder>() {

    fun setList(mTVShow : List<TVShow>){
        tvShows.clear()
        tvShows.addAll(mTVShow)
        notifyDataSetChanged()
    }

    inner class TVShowViewHolder(private val binding: ItemCardBinding) : RecyclerView.ViewHolder(binding.root) {
        fun bind(tvShow : TVShow){
            binding.root.setOnClickListener { tvShowAdapterInterface.onTap(tvShow) }
            binding.root.setOnLongClickListener {
                tvShowAdapterInterface.onLongTap(tvShow)
                return@setOnLongClickListener true
            }
            Glide.with(binding.root).load(tvShow.banner).into(binding.ivBanner)
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): TVShowViewHolder {
        val view = ItemCardBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return TVShowViewHolder(view)
    }

    override fun getItemCount(): Int = tvShows.size

    override fun onBindViewHolder(holder: TVShowViewHolder, position: Int) = holder.bind(tvShows[position])

}