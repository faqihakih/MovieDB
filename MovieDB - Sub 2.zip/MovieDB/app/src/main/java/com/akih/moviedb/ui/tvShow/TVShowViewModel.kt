package com.akih.moviedb.ui.tvShow

import androidx.lifecycle.LiveData
import androidx.lifecycle.ViewModel
import com.akih.moviedb.data.source.remote.response.TVShow
import com.akih.moviedb.data.MovieRepository

class TVShowViewModel (private val movieRepository: MovieRepository) : ViewModel() {
    fun getAllTVShow(): LiveData<List<TVShow>> = movieRepository.getAllTVShow()
}