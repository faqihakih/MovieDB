package com.akih.moviedb.ui.detail.movie

import android.annotation.SuppressLint
import android.content.Intent
import android.net.Uri
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import com.akih.moviedb.data.source.remote.response.Movie
import com.akih.moviedb.databinding.ActivityDetailMovieBinding
import com.akih.moviedb.viewModel.ViewModelFactory
import com.bumptech.glide.Glide

class DetailMovieActivity : AppCompatActivity() {
    private lateinit var movieViewModel: DetailMovieViewModel
    private lateinit var binding: ActivityDetailMovieBinding
    private lateinit var factory : ViewModelFactory
    companion object{
        const val EXTRA_ID = "extra_id"
    }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityDetailMovieBinding.inflate(layoutInflater)
        setContentView(binding.root)
        initViewModel()
        getId()
        observe()
    }

    private fun initViewModel(){
        factory = ViewModelFactory.getInstance(this)
        movieViewModel = ViewModelProvider(this, factory)[DetailMovieViewModel::class.java]
    }
    private fun getId(){
        val id = intent.extras
        if (id != null){
            val data = id.getInt(EXTRA_ID, 0)
            movieViewModel.setSelectedMovie(data)
        }
    }

    @SuppressLint("SetTextI18n")
    private fun initView(itemData : Movie){
        Glide.with(this.applicationContext).load(itemData.banner).into(binding.ivBanner)
        binding.apply {
            tvTitle.text = "${itemData.title} - (${itemData.year})"
            tvDuration.text = itemData.duration
            tvRating.text = itemData.rating
            tvGenre.text = itemData.genre
            tvSynopsis.text = itemData.synopsis
        }
    }

    private fun observe(){
        movieViewModel.getMovie().observe(this, Observer { initView(it) })
        movieViewModel.getMovie().observe(this, Observer { watchTrailer(it) })
    }

    private fun watchTrailer(itemData : Movie){
        binding.btnTrailer.setOnClickListener {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(itemData.trailer)))
        }
    }
}