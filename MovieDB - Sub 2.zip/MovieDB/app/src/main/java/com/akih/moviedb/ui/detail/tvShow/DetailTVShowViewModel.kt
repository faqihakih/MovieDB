package com.akih.moviedb.ui.detail.tvShow

import androidx.lifecycle.LiveData
import androidx.lifecycle.ViewModel
import com.akih.moviedb.data.source.remote.response.TVShow
import com.akih.moviedb.data.MovieRepository

class DetailTVShowViewModel (private val movieRepository: MovieRepository) : ViewModel() {
    private var tvShowId : Int = 0
    fun setSelectedTVShow(tvShowsId : Int){
        this.tvShowId = tvShowsId
    }

    fun getTVShow() : LiveData<TVShow> = movieRepository.getTVShowDetail(tvShowId)
}